#' The application server-side
#'
#' @param input,output,session Internal parameters for {shiny}.
#'     DO NOT REMOVE.
#' @import shiny
#' @noRd
app_server <- function(input, output, session) {

  mod_serie_historica_server("serie_historica_1")
  mod_mapa_estacao_server("mapa_estacao_1")

}
