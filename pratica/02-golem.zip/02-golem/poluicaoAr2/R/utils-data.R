#' Base de dados da Cetesb
#'
#' @format
#' \describe{
#'   \item{estacao_cetesb}{estacao_cetesb}
#'   \item{poluente}{poluente}
#'   \item{data}{data}
#'   \item{hora}{hora}
#'   \item{concentracao}{concentracao}
#'   \item{lat}{lat}
#'   \item{long}{long}
#' }
"cetesb"
