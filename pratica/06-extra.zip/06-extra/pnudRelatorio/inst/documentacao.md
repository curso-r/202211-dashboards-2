# Documentação

## Título

Esse aplicativo utiliza a base do **pnud**, das [nações unidas](https://www.undp.org/).

Essa base tem informações de

1. Renda
1. Longevidade
1. Educação

A nível municipal, em 3 anos distintos (anos do Censo).

![](http://www.atlasbrasil.org.br/img/icon-atlas.svg)
